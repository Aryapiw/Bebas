const express = require('express');
const multer = require('multer');
const File = require('../models/fileModel');

const router = express.Router();

// Middleware for IP Restriction
router.use((req, res, next) => {
  const allowedIP = "192.168.1.1"; // Replace with your IP
  if (req.ip !== allowedIP) return res.status(403).send('Access Denied');
  next();
});

// Multer Configuration
const storage = multer.diskStorage({
  destination: './uploads',
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Admin Panel
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'arya' && password === 'arya') {
    return res.redirect('/admin/admin.html');
  }
  res.status(401).send('Unauthorized');
});

router.post('/upload', upload.single('file'), async (req, res) => {
  const { title, description } = req.body;
  const newFile = new File({
    title,
    description,
    fileUrl: `/uploads/${req.file.filename}`
  });
  await newFile.save();
  res.send('File Uploaded Successfully');
});

module.exports = router;