const express = require('express');
const File = require('../models/fileModel');

const router = express.Router();

// Get All Files
router.get('/files', async (req, res) => {
  try {
    const files = await File.find();
    res.status(200).json(files);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch files' });
  }
});

// Get a Single File by ID
router.get('/files/:id', async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) return res.status(404).json({ error: 'File not found' });
    res.status(200).json(file);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch file' });
  }
});

// Add a Comment to a File
router.post('/files/:id/comment', async (req, res) => {
  try {
    const { username, content } = req.body;
    const file = await File.findById(req.params.id);

    if (!file) return res.status(404).json({ error: 'File not found' });

    file.comments.push({ username, content, replies: [] });
    await file.save();
    res.status(200).json(file);
  } catch (err) {
    res.status(500).json({ error: 'Failed to add comment' });
  }
});

// Reply to a Comment
router.post('/files/:fileId/comments/:commentId/reply', async (req, res) => {
  try {
    const { username, content } = req.body;
    const file = await File.findById(req.params.fileId);

    if (!file) return res.status(404).json({ error: 'File not found' });

    const comment = file.comments.id(req.params.commentId);

    if (!comment) return res.status(404).json({ error: 'Comment not found' });

    comment.replies.push({ username, content });
    await file.save();
    res.status(200).json(file);
  } catch (err) {
    res.status(500).json({ error: 'Failed to reply to comment' });
  }
});

// Add a Rating to a File
router.post('/files/:id/rate', async (req, res) => {
  try {
    const { rating } = req.body;
    const file = await File.findById(req.params.id);

    if (!file) return res.status(404).json({ error: 'File not found' });

    file.ratings.push(rating);
    await file.save();
    res.status(200).json(file);
  } catch (err) {
    res.status(500).json({ error: 'Failed to rate file' });
  }
});

module.exports = router;