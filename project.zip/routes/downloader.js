const express = require('express');
const File = require('../models/fileModel');

const router = express.Router();

// Get All Files
router.get('/files', async (req, res) => {
  const files = await File.find();
  res.json(files);
});

// Add Comment
router.post('/files/:id/comment', async (req, res) => {
  const { username, content } = req.body;
  const file = await File.findById(req.params.id);
  file.comments.push({ username, content, replies: [] });
  await file.save();
  res.json(file);
});

// Reply to Comment
router.post('/files/:fileId/comments/:commentId/reply', async (req, res) => {
  const { username, content } = req.body;
  const file = await File.findById(req.params.fileId);
  const comment = file.comments.id(req.params.commentId);
  comment.replies.push({ username, content });
  await file.save();
  res.json(file);
});

// Rate File
router.post('/files/:id/rate', async (req, res) => {
  const { rating } = req.body;
  const file = await File.findById(req.params.id);
  file.ratings.push(rating);
  await file.save();
  res.json(file);
});

module.exports = router;