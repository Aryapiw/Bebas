const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
  title: String,
  description: String,
  fileUrl: String,
  ratings: { type: [Number], default: [] },
  comments: [{
    username: String,
    content: String,
    replies: [{ username: String, content: String }]
  }]
});

module.exports = mongoose.model('File', fileSchema);