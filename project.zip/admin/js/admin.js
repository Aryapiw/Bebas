document.addEventListener('DOMContentLoaded', () => {
  // Add custom functionalities here (if needed in the future)
});