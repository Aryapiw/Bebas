const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');

// Import Routes
const adminRoutes = require('./routes/admin');
const downloaderRoutes = require('./routes/downloader');

// Initialize App
const app = express();

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/downloaderDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('Database Connected'))
  .catch(err => console.error(err));

// Routes
app.use('/admin', adminRoutes);
app.use('/', downloaderRoutes);

// Start Server
app.listen(3000, () => console.log('Server running on http://localhost:3000'));