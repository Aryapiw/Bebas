document.addEventListener('DOMContentLoaded', () => {
  const fileContainer = document.getElementById('file-container');

  // Fetch all files
  fetch('/files')
    .then(res => res.json())
    .then(files => {
      files.forEach(file => {
        const card = document.createElement('div');
        card.className = 'file-card';
        card.innerHTML = `
          <h3>${file.title}</h3>
          <p>${file.description}</p>
          <a href="${file.fileUrl}" download><button>Download</button></a>
          <div class="comments">
            <strong>Comments:</strong>
            <ul>${file.comments.map(comment => `<li>${comment.username}: ${comment.content}</li>`).join('')}</ul>
          </div>
        `;
        fileContainer.appendChild(card);
      });
    });
});